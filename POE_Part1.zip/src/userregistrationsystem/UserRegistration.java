package userregistrationsystem;

import java.util.Scanner;

public class UserRegistration {
 
    private static String username;
    private static String password;
    private static String cellphoneNumber;
    private static String name;
    private static String surname;

   
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);

        System.out.println("*****User Registration*****");

        // ==================
        // NAME AND SURNAME
        // ==================
        System.out.print("Please enter your name: ");
        name = input.nextLine();

        if (name.isEmpty()) {
            System.out.println("First name cannot be empty");
            return;
        }

        System.out.print("Please enter your last name: ");
        surname = input.nextLine(); 
        
          if (surname.isEmpty()) {
            System.out.println("Last name cannot be empty");
            return;
        }

        // Create Login object with names
        Login login = new Login(name, surname);
        
        // ==================
        // CELLPHONE LOOP
        // ==================
        while (true) {
            System.out.println("Enter your Cellphone Number (e.g., +27715220163):");
            cellphoneNumber = input.nextLine();

            if (login.checkCellPhoneNumber(cellphoneNumber)) {
                System.out.println("Cellphone number successfully captured.");
                break; // Exit loop if valid
            } else {
                System.out.println("Cellphone number is not correctly formatted.");
                System.out.println("Cellphone number must contain an international code (e.g., +27).");
            }
        }
        // ==================
        // USERNAME LOOP
        // ==================
        while (true) {
            System.out.println("Enter your username (must contain '_' and be <= 5 characters):");
            username = input.nextLine();

            if (login.checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break; // Exit loop if valid
            } else {
                System.out.println("Username is not correctly formatted.");
                System.out.println("Username must contain an underscore (_) and be no more than 5 characters long.");
            }
        }
        // ==================
        // PASSWORD LOOP
        // ==================
        while (true) {
            System.out.println("Enter your password (min 8 characters, 1 capital letter, 1 number, 1 special character):");
            password = input.nextLine();

            if (login.checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured.");
                break; // Exit loop if valid
            } else {
                System.out.println("Password is not correctly formatted.");
                System.out.println("Password must contain at least 8 characters, a capital letter, a number, and a special character.");
            }
        }
        // ==================
        // REGISTER AND LOGIN
        // ==================
        String regStatus = login.registerUser(username, password, cellphoneNumber, name, surname);
        System.out.println("\n" + regStatus);

        // If registration is successful, allow login
        if (regStatus.equals("Registration successful.")) {
            System.out.println("\n*****User Login*****");

            System.out.print("Enter the username you created: ");
            String loginUser = input.nextLine();

            System.out.print("Enter the password you created: ");
            String loginPass = input.nextLine();

            String loginStatus = login.returnLoginStatus(loginUser, loginPass);
            System.out.println(loginStatus);
        }
        
        input.close();
    }
    
}


